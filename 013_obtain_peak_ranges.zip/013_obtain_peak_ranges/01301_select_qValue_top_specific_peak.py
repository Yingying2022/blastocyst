import pandas as pd
from pathlib import Path

# 设置输入样本列表
sample_list_file = "/mnt/helab3/yyhan/Projects/embryo_classification/Tables/GEO_fastq_list/sample_list.txt"

# 设置参数
suffix = "_merged_0.8_peaks_sorted_mainpeak_top20000_flanked5kb_dist_5000_merged_specific"
top_n = 1000

with open(sample_list_file) as f:
    samples = [line.strip() for line in f if line.strip()]

for sample in samples:
    input_file = Path(f"{sample}{suffix}.bed")
    output_file = Path(f"{sample}{suffix}_top{top_n}.tsv")
    bed_file = output_file.with_suffix('.bed')

    if not input_file.exists():
        print(f"⚠️ 文件不存在: {input_file}")
        continue

    try:
        df = pd.read_csv(input_file, sep='\t')
    except Exception as e:
        print(f"❌ 读取失败: {input_file}, 错误: {e}")
        continue

    # 排序：按第4列降序（qValue 或 score）
    df_sorted = df.sort_values(by=df.columns[3], ascending=False)
    df_top = df_sorted.head(top_n)

    # 保存 .tsv 文件（可选）
    df_top.to_csv(output_file, sep='\t', header=True, index=False)

    # 输出 BED 文件（取前三列 + 第四列）
    df_top_sorted_bed = df_top.sort_values(by=[df.columns[0], df.columns[1]])
    df_top_sorted_bed.to_csv(
        bed_file,
        sep='\t',
        header=False,
        index=False
    )

    print(f"✅ 已处理: {output_file.name} 和 {bed_file.name}")
