#!/bin/bash

# 输入：sample列表
sample_list="/mnt/helab3/yyhan/Projects/embryo_classification/Tables/GEO_fastq_list/sample_list.txt"
bed_dir="/mnt/helab3/yyhan/Projects/embryo_classification/fastq_form_liumin/selected_20fastq/01_merged_bam_20fq_callpeak_0.8/04_marker_cell_specific_peaks_top1000"   # 存放所有 marker 的 .bed 文件的目录
output_dir="coverage_results"
mkdir -p $output_dir

# 提取所有 marker 名称
markers=$(cut -d'_' -f1 "$sample_list" | sort -u)

# 对每个 marker 处理
for marker in $markers; do
    echo "Processing $marker..."

    # 找出这个 marker 下所有样本行
    samples=($(grep "^${marker}_" "$sample_list"))

    # 准备 bw 文件路径数组
    bw_files=()
    labels=()
    for sample in "${samples[@]}"; do
        bw_path="${sample}/${sample}.bw"
        if [ -f "$bw_path" ]; then
            bw_files+=("$bw_path")
            labels+=("$sample")
        else
            echo "Warning: missing $bw_path"
        fi
    done

    # 组装 bw参数字符串
    bw_args=$(printf " %s" "${bw_files[@]}")
    label_args=$(printf " %s" "${labels[@]}")

    # 对应的 bed 文件名
    bed_file="${bed_dir}/${marker}_combined_cell_specific_annotated_merged_0.8_peaks_sorted_mainpeak_top20000_flanked5kb_dist_5000_merged_specific_top1000.bed"

    if [ ! -f "$bed_file" ]; then
        echo "Error: missing BED file for $marker: $bed_file"
        continue
    fi

    # 输出文件
    out_npz="${output_dir}/${marker}.npz"

    # 执行 multiBigwigSummary
    echo "Running multiBigwigSummary for $marker..."
    multiBigwigSummary BED-file \
        -b $bw_args \
        --labels $label_args \
        --BED "$bed_file" \
        -o "$out_npz"

    echo "$marker done."
done
