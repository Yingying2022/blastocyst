#!/bin/bash

output_dir="../02_flanked5kb_filtered_mainpeak"
mkdir -p "$output_dir"

for file in *_merged_0.8_peaks_sorted_mainpeak.bed; do
  echo "Processing $file"
  output_file="${output_dir}/${file%.bed}_flanked5kb.bed"
  bedtools slop \
    -i "$file" \
    -g /mnt/helab1/00_public/02_genome/11_mm10/chr_length.txt \
    -b 5000 \
    > "$output_file"
done
