#!/bin/bash
suffix="merged_0.8_peaks_sorted_mainpeak_top20000_flanked5kb_dist_5000_merged"
# 组蛋白修饰列表
markers=("H3K4me1" "H3K27ac" "H3K36me3" "H3K9me3" "H3K27me3" "H3K4me3")

# 细胞类型列表
cell_types=("zygote" "2cell" "4cell" "8cell" "morula" "blastocyst")

output_dir="../04_marker_cell_specific_peaks"
mkdir -p "$output_dir"
# 日志文件
log_file="${suffix}.log"
# 记录没有特异性区域的文件
no_specific_peaks_file="no_specific_peaks.txt"
# 针对每一个组蛋白修饰
for marker in "${markers[@]}"; do
    echo "Processing marker: $marker"

    # 针对每一个细胞类型
    for cell_type in "${cell_types[@]}"; do
        echo "  Finding specific peaks for $cell_type"

        marker_cell_peak_file="$marker"_"$cell_type"_"$suffix".bed
        # 创建一个临时文件来存储所有其他细胞类型的合并bed
        other_peaks_temp=$(mktemp)

        # 收集所有其他细胞类型的文件，合并并去重
        echo "" > "$other_peaks_temp"  # 清空文件

        for other_cell_type in "${cell_types[@]}"; do
            if [ "$cell_type" != "$other_cell_type" ]; then
                cat "$marker"_"$other_cell_type"_"$suffix".bed >> "$other_peaks_temp"
            fi
        done

        # 排序并合并重叠的peak（bedtools intersect 要求排序）
        sort -k1,1 -k2,2n "$other_peaks_temp" | bedtools merge -d 5000 -i - > "${other_peaks_temp}.merged"

        # 找出当前细胞类型中，不在其他任何细胞类型中出现的 peak
        bedtools intersect -v \
            -a "$marker_cell_peak_file" \
            -b "${other_peaks_temp}.merged" \
            > "$output_dir/${marker}_${cell_type}_${suffix}_specific.bed"
        if [ ! -f "$output_dir/${marker}_${cell_type}_${suffix}_specific.bed" ]; then
            echo "$(date) - No specific peaks found for $marker in $cell_type (File not generated). Skipping..." >> "$log_file"
            # 记录没有特异性区域的细胞和 marker 到文件
            echo "$marker in $cell_type" >> "$no_specific_peaks_file"
        elif [ ! -s "$output_dir/${marker}_${cell_type}_${suffix}_specific.bed" ]; then
            echo "$(date) - File generated but empty for $marker in $cell_type. Skipping..." >> "$log_file"
            # 记录没有特异性区域的细胞和 marker 到文件
            echo "$marker in $cell_type" >> "$no_specific_peaks_file"
        else
            echo "$(date) - Saved: $output_dir/${marker}_${cell_type}_specific.bed" >> "$log_file"
        fi

        # 清理临时文件
        rm "$other_peaks_temp" "${other_peaks_temp}.merged"

        echo "    Saved: $output_dir/${marker}_${cell_type}_${suffix}_specific.bed"
    done
done

echo "All cell-type-specific peaks have been identified."


