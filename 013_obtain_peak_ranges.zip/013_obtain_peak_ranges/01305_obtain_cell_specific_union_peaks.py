# import pandas as pd
# import glob
# import os
#
# # 找到所有目标文件
# bed_files = glob.glob("*_merged_0.8_peaks_sorted_mainpeak_top20000_flanked5kb_dist_5000_merged_specific_top1000.bed")
#
# all_dfs = []
#
# for bed_file in bed_files:
#     # 提取 marker 和 celltype
#     basename = os.path.basename(bed_file)
#     parts = basename.split("_")
#     marker = parts[0]
#     celltype = parts[1]
#
#     # 读取 bed 文件（无 header）
#     df = pd.read_csv(bed_file, sep='\t', header=None)
#
#     # 添加 marker 和 celltype 列
#     df["marker"] = marker
#     df["celltype"] = celltype
#
#     all_dfs.append(df)
#
# # 合并所有 DataFrame
# merged_df = pd.concat(all_dfs, ignore_index=True)
#
# # 保存合并结果
# merged_df.to_csv("merged_annotated.bed", sep='\t', header=False, index=False)

import pandas as pd
import glob
import os
from collections import defaultdict

# 获取所有 .bed 文件（可为软链接）
bed_files = glob.glob("*.bed")

# 字典：marker -> 所有文件
marker_groups = defaultdict(list)

# 解析每个文件，按 marker 分组
for file in bed_files:
    basename = os.path.basename(file)
    parts = basename.split("_")
    if len(parts) < 2:
        continue  # 跳过无法解析的文件名
    marker = parts[0]
    celltype = parts[1]
    marker_groups[marker].append((file, celltype))

# 合并每个 marker 的所有文件
for marker, file_list in marker_groups.items():
    all_dfs = []
    for file, celltype in file_list:
        try:
            df = pd.read_csv(file, sep="\t", header=None, usecols=[0, 1, 2])  # 只保留 chr, start, end
            df["marker"] = marker
            df["celltype"] = celltype
            all_dfs.append(df)
        except Exception as e:
            print(f"读取 {file} 失败: {e}")

    if all_dfs:
        combined_df = pd.concat(all_dfs, ignore_index=True)
        combined_df.to_csv(f"{marker}_combined_cell_specific_annotated.bed", sep="\t", header=False, index=False)
        print(f"已保存：{marker}_combined_cell_specific_annotated.bed")

