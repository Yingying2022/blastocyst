# import os
# import matplotlib.pyplot as plt
# import numpy as np
# # 新建输出目录
# output_dir = "peak_length_histograms"
# os.makedirs(output_dir, exist_ok=True)
#
# # 只处理 .bed 文件
# bed_files = [f for f in os.listdir('.') if f.endswith('_merged_0.8_peaks_sorted.broadPeak')]
#
# for bed in bed_files:
#     peak_lengths = []
#     with open(bed) as f:
#         for line in f:
#             if line.startswith('#') or line.strip() == '':
#                 continue
#             cols = line.strip().split()
#             start = int(cols[1])
#             end = int(cols[2])
#             peak_lengths.append(end - start)
#
#         # log10 转换（横坐标）
#     log_lengths = np.log10(peak_lengths)
#
#     # 画图
#     plt.figure()
#     plt.hist(log_lengths, bins=50, log=True, edgecolor='black')  # log=True 是对 y 轴 log10
#     plt.title(f'Log-Log Peak Length Distribution\n{bed}')
#     plt.xlabel('log10(Peak length in bp)')
#     plt.ylabel('log10(Count)')
#     plt.grid(True)
#     plt.tight_layout()
#
#     # 保存图像
#     output_file = os.path.join(output_dir, f'{bed}_loglog_peak_length_hist.png')
#     plt.savefig(output_file)
#     print(f'Saved log-log histogram for {bed} -> {output_file}')
#     plt.close()

import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.mixture import GaussianMixture
from scipy.stats import anderson

# 创建输出文件夹
output_dir = '../01_filtered_mainpeak_results'
os.makedirs(output_dir, exist_ok=True)

# 扫描所有 broadPeak 文件
peak_files = [f for f in os.listdir('.') if f.endswith('_merged_0.8_peaks_sorted.broadPeak')]

for bed in peak_files:
    print(f'\nProcessing {bed}...')

    # 读取 bed 文件 (chrom, start, end 至少三列)
    df = pd.read_csv(bed, sep='\t', header=None)
    df = df[[0, 1, 2, 8]]  # 只保留前三列和qValue
    df.columns = ['chr', 'start', 'end', 'qValue']

    # 计算长度和 log10(长度)
    df['length'] = df['end'] - df['start']
    df = df[df['length'] > 0]
    df['log_length'] = np.log10(df['length'])

    # 用 GMM 分成两组
    X = df[['log_length']].values
    gmm = GaussianMixture(n_components=2, random_state=0).fit(X)
    df['gmm_group'] = gmm.predict(X)

    # 判断哪个是主峰组（平均 log_length 较大）
    means = gmm.means_.flatten()
    main_group = np.argmax(means)
    df_main = df[df['gmm_group'] == main_group]

    # 正态性检验：Anderson-Darling
    result = anderson(df_main['log_length'], dist='norm')
    stat = result.statistic
    critical_value = result.critical_values[2]  # 常用5%显著性水平
    significance = result.significance_level[2]
    passes = stat < critical_value

    print(f"Anderson-Darling stat: {stat:.4f} | 5% critical value: {critical_value:.4f} | Passes normality: {passes}")

    # 保存筛选后的主峰为 bed 文件
    out_bed = os.path.join(output_dir, bed.replace('.broadPeak', '_mainpeak.bed'))
    df_main[['chr', 'start', 'end', 'qValue']].to_csv(out_bed, sep='\t', header=False, index=False)
    df_main[['chr', 'start', 'end', 'qValue', 'length']].to_csv(out_bed.replace('.bed', '.tsv'), sep='\t', index=False)
    print(f'Saved main peak BED: {out_bed} ({len(df_main)} peaks kept)')


    # 画直方图对比（筛选前 vs 后）
    plt.figure(figsize=(10, 4))
    plt.subplot(1, 2, 1)
    plt.hist(df['log_length'], bins=50, alpha=0.7)
    plt.title(f'Before filtering\n{bed}')

    plt.subplot(1, 2, 2)
    plt.hist(df_main['log_length'], bins=50, alpha=0.7)
    plt.title(f'After filtering (main peak)\n{bed}')

    plot_path = os.path.join(output_dir, bed.replace('.broadPeak', '_loglen_hist.png'))
    plt.tight_layout()
    plt.savefig(plot_path)
    plt.close()
    print(f'Saved histogram: {plot_path}')
