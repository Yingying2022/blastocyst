import pandas as pd
from pathlib import Path

# 设置输入样本列表
sample_list_file = "/mnt/helab3/yyhan/Projects/embryo_classification/Tables/GEO_fastq_list/sample_list.txt"

# 设置参数
suffix = "_merged_0.8_peaks_sorted_mainpeak_top20000_flanked5kb_dist_5000_merged_specific"
top_n = 1000

# 读取样本列表
with open(sample_list_file) as f:
    samples = [line.strip() for line in f if line.strip()]

# 遍历每个样本
for sample in samples:
    input_file = Path(f"{sample}{suffix}.tsv")
    output_file = Path(f"{sample}{suffix}_top{top_n}.tsv")

    if not input_file.exists():
        print(f"⚠️ 文件不存在: {input_file}")
        continue

    # 读取带 header 的 TSV 文件
    df = pd.read_csv(input_file, sep='\t')  # 默认 header=0

    # 排序：按 qValue 降序（你也可以根据实际列名调整）
    df_sorted = df.sort_values(by='qValue', ascending=False)

    # 取前 top_n 行
    df_top = df_sorted.head(top_n)

    # 保存并保留 header
    df_top.to_csv(output_file, sep='\t', header=True, index=False)
    # 排序并保存为 .bed 文件
    bed_file = output_file.with_suffix('.bed')

    # 按 chr 和 start 排序，确保 BED 工具兼容性
    df_top_sorted_bed = df_top[['chr', 'start', 'end', 'qValue']].sort_values(by=['chr', 'start'])

    df_top_sorted_bed.to_csv(
        bed_file,
        sep='\t',
        header=False,  # 标准 BED 文件无表头
        index=False
    )

    print(f"✅ 已处理并保存: {output_file}")
