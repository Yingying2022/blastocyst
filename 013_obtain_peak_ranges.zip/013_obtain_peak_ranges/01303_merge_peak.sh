dist=5000
output_dir="../03_merged_flanked5kb_filtered_mainpeak"
mkdir -p $output_dir
for file in *merged_0.8_peaks_sorted_mainpeak_flanked5kb.bed; do
  echo "Proecssing $file"
  base=$(basename "$file" .bed)
  sort -k1,1 -k2,2n $file | \
  bedtools merge -d 5000 -c 4 -o max > "${output_dir}/${base}_dist_${dist}_merged.bed"
done

echo "Done!"