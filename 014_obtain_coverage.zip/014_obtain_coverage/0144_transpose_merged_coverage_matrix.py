import pandas as pd

# 读取原始表格
df = pd.read_csv("merged_all_samples.tsv", sep="\t")

# 转置，保留 header 作为新列索引
df_t = df.set_index("region").T

# 保存原始行名作为 sample_name
df_t["sample_name"] = df_t.index

# 提取 stage 名称（去掉编号）
df_t["stage"] = df_t["sample_name"].apply(lambda x: x.split("_")[0])

# 重置索引并保存
df_t.reset_index(drop=True, inplace=True)
df_t.to_csv("transposed_with_stage.tsv", sep="\t", index=False)
