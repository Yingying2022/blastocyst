import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import math
marker = "H3K27ac"
input_dir = f"/mnt/helab3/yyhan/Projects/embryo_classification/fastq_form_liumin/selected_20fastq/00_fastq/bigWig_all_renamed_sample/coverage_over_cell_specific_peak/{marker}_matrix.npz"
matrix_data = np.load(input_dir)
print(matrix_data.files)

data = matrix_data["matrix"]   # 2D numpy array
labels = matrix_data["labels"] # 1D array of strings

print(data.shape)
# print(labels)

# 如果 data 中有 0，建议用 log1p（= log(1 + x)）避免 -inf：
# log_data = np.log1p(data)

# # 画图
# plt.figure(figsize=(12, 10))
# sns.heatmap(log_data, cmap="viridis", yticklabels=False, xticklabels=labels, cbar_kws={'label': 'log1p(Signal)'})
# plt.xticks(rotation=90, fontsize=6)
# plt.title("Log-Scaled H3K9me3 Signal Heatmap")
# plt.tight_layout()
# plt.savefig("H3K9me3_heatmap.png", dpi=300)
# plt.show()


# 对信号取 log1p 变换
log_data = np.log1p(data)

# 使用 clustermap 进行聚类
g = sns.clustermap(
    log_data,
    cmap="viridis",
    xticklabels=labels,
    yticklabels=False,
    figsize=(12, 10),
    col_cluster=True,  # 是否对列聚类
    row_cluster=False,  # 是否对行聚类
    cbar_kws={'label': 'log1p(Signal)'}
)

# 美化输出
plt.setp(g.ax_heatmap.xaxis.get_majorticklabels(), rotation=90, fontsize=6)
g.suptitle(f"Clustered {marker} Signal Heatmap", fontsize=14)
g.savefig(f"{marker}_heatmap_clustered.png", dpi=300)
plt.show()


# 转换为 DataFrame
df = pd.DataFrame(data, columns=labels)

bed_file = "your_regions.bed"
bed_df = pd.read_csv(bed_file, sep="\t", header=None, names=["chr", "start", "end"])

# 确保行数对得上
assert bed_df.shape[0] == data.shape[0]

# 合成 region 字符串：chr:start-end
bed_df["region"] = bed_df["chr"] + ":" + bed_df["start"].astype(str) + "-" + bed_df["end"].astype(str)

# 把 region 列添加到信号矩阵前面
df.insert(0, "region", bed_df["region"])

# 保存
df.to_csv("H3K9me3_signal_matrix_with_regions.tsv", sep="\t", index=False)
