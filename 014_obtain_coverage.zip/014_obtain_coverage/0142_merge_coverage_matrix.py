import os
import pandas as pd
from glob import glob
from tqdm import tqdm

# 所有包含 tsv 文件的样本文件夹路径（如 "4cell_992"）
root_dir = "/mnt/helab3/yyhan/Projects/embryo_classification/fastq_form_liumin/selected_20fastq/01_merged_bam_20fq_callpeak_0.8/05_coverge_cell_specific_peak/00_coverage_signal/6stage_1000cells"  # <- 父目录路径
sample_dirs = [d for d in os.listdir(root_dir) if os.path.isdir(os.path.join(root_dir, d))]

# 存储每个样本数据（字典：key 为样本名，value 为 DataFrame）
sample_data = {}
regions = None

for sample in tqdm(sample_dirs):
    folder_path = os.path.join(root_dir, sample)
    tsv_files = glob(os.path.join(folder_path, "*.tsv"))
    
    if not tsv_files:
        print(f"⚠️ {sample} 文件夹中没有 .tsv 文件，跳过")
        continue

    if len(tsv_files) > 1:
        print(f"⚠️ {sample} 文件夹中有多个 .tsv 文件，默认使用第一个")

    tsv_file = tsv_files[0]
    df = pd.read_csv(tsv_file, sep="\t")
    
    if "region" not in df.columns:
        print(f"⚠️ {tsv_file} 缺少 region 列，跳过")
        continue

    # 初始化 region 顺序
    if regions is None:
        regions = df["region"]
    else:
        # 确保 region 一致
        if not df["region"].equals(regions):
            print(f"❌ {sample} 的 region 与其他样本不一致，跳过")
            continue

    # 将 marker 值合并为一列（取所有非 region 列的和或平均）
    values = df.drop(columns=["region"]).sum(axis=1, skipna=True)  # 或者使用 mean(axis=1)
    sample_data[sample] = values

# 拼接所有列
final_df = pd.DataFrame({"region": regions})

for sample, values in sample_data.items():
    final_df[sample] = values



# 保存结果
output_file = "merged_all_samples.tsv"
final_df.to_csv(output_file, sep="\t", index=False)
print(f"\n✅ 合并完成，输出文件: {output_file}")
