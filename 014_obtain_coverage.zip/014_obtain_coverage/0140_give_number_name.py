import os
import pandas as pd

# 配置路径
bw_dir = "bigWig_all"          # 存放原始 .bw 文件的目录
output_dir = "bigWig_all_renamed_sample"  # 放软链接的目标目录
csv_file = "/mnt/helab3/yyhan/Projects/embryo_classification/Tables/GEO_fastq_list/geo_samples_numbered.csv"  # 你的 CSV 文件名

# 创建目标目录
os.makedirs(output_dir, exist_ok=True)

# 读取 CSV 文件
df = pd.read_csv(csv_file)

# 遍历每一行
for _, row in df.iterrows():
    run_id = row['Run']
    new_name = row['sample_name_numbered'] + ".bw"

    # 查找原始bw文件
    for filename in os.listdir(bw_dir):
        if filename.startswith(run_id) and filename.endswith(".bw"):
            old_path = os.path.join(bw_dir, filename)
            new_path = os.path.join(output_dir, new_name)
            print(f"Renaming: {old_path} -> {new_path}")
            os.rename(old_path, new_path)  # 改成 os.link / shutil.copy2 也可以
            break
    else:
        print(f"WARNING: No file found for {run_id}")
