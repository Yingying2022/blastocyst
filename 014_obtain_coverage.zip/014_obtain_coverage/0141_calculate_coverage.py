import pandas as pd
import os
from glob import glob
import subprocess

# 所有bed文件所在路径
bed_dir = "/mnt/helab3/yyhan/Projects/embryo_classification/fastq_form_liumin/selected_20fastq/01_merged_bam_20fq_callpeak_0.8/04_marker_cell_specific_peaks_top1000/"
bw_dir = "."
output_dir = "coverage_over_cell_specific_peak/"

os.makedirs(output_dir, exist_ok=True)

# 找到所有 marker 的 .bed 文件
bed_files = glob(os.path.join(bed_dir, "*.3col.bed"))

for bed_file in bed_files:
    print(f"Processing: {bed_file}")
    # 提取 marker 名（假设 bed 文件名是 H3K27ac_something.bed）
    filename = os.path.basename(bed_file)
    marker = filename.split("_")[0]

    # 找出所有以 marker 开头的 .bw 文件
    bw_files = sorted(glob(os.path.join(bw_dir, f"{marker}_*.bw")))
    
    if not bw_files:
        print(f"⚠️ No bw files found for marker: {marker}")
        continue

    # 输出文件名
    matrix_out = os.path.join(output_dir, f"{marker}_matrix.npz")

    # 调用 deepTools 的 multiBigwigSummary
    cmd = [
        "multiBigwigSummary", "BED-file",
        "--bwfiles", *bw_files,
        "--BED", bed_file,
        "--outFileName", matrix_out
    ]
    print("Running:", " ".join(cmd))
    subprocess.run(cmd)
