import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import math
markers = {"H3K27ac", "H3K9me3", "H3K4me3", "H3K4me1", "H3K27me3", "H3K36me3"}
for marker in markers:
    input_dir = f"/mnt/helab3/yyhan/Projects/embryo_classification/fastq_form_liumin/selected_20fastq/00_fastq/bigWig_all_renamed_sample/coverage_over_cell_specific_peak/{marker}_matrix.npz"
    matrix_data = np.load(input_dir)
    print(matrix_data.files)

    data = matrix_data["matrix"]   # 2D numpy array
    labels = matrix_data["labels"] # 1D array of strings

    # print(data.shape)
    # print(data[0])

    # 转换为 DataFrame
    df = pd.DataFrame(data, columns=labels)

    bed_file = f"/mnt/helab3/yyhan/Projects/embryo_classification/fastq_form_liumin/selected_20fastq/01_merged_bam_20fq_callpeak_0.8/04_marker_cell_specific_peaks_top1000/{marker}_combined_cell_specific_annotated_merged_0.8_peaks_sorted_mainpeak_top20000_flanked5kb_dist_5000_merged_specific_top1000.3col.bed"
    bed_df = pd.read_csv(bed_file, sep="\t", header=None, names=["chr", "start", "end"])

    # 确保行数对得上
    assert bed_df.shape[0] == data.shape[0]

    # 合成 region 字符串：chr:start-end
    bed_df["region"] = bed_df["chr"] + ":" + bed_df["start"].astype(str) + "-" + bed_df["end"].astype(str)

    # 把 region 列添加到信号矩阵前面
    df.insert(0, "region", bed_df["region"])

    # 保存
    df.to_csv(f"{marker}_signal_matrix_with_regions.tsv", sep="\t", index=False)

print("Done!")