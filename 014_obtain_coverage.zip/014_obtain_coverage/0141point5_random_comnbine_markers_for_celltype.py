import pandas as pd
import os
import random

# 固定随机种子（保证可复现）
random.seed(42)
output_all = "/mnt/helab3/yyhan/Projects/embryo_classification/fastq_form_liumin/selected_20fastq/01_merged_bam_20fq_callpeak_0.8/05_coverge_cell_specific_peak/00_coverage_signal/6stage_1000cells"
# 参数
stages = ["zygote", "2cell", "4cell", "8cell", "morula", "blastocyst"]

markers = ["H3K27ac", "H3K27me3", "H3K36me3", "H3K4me1", "H3K4me3", "H3K9me3"]
num_combinations = 1000

for stage in stages:
    print(f"\n🔄 Processing stage: {stage}")
    stage_dir = stage
    marker_to_df = {}
    marker_to_columns = {}

    # 加载每个 marker 的 signal matrix
    for marker in markers:
        filepath = os.path.join(stage_dir, f"{marker}_{stage}_signal_matrix.tsv")
        df = pd.read_csv(filepath, sep="\t")
        marker_to_df[marker] = df
        marker_to_columns[marker] = df.columns[1:].tolist()  # 除 region 外的列

    # 保存组合信息
    combo_log = []
    used_combos = set()

    for i in range(1, num_combinations + 1):
        while True:
            selected = {}
            selected_keys = []

            for marker in markers:
                col = random.choice(marker_to_columns[marker])
                selected[marker] = col
                selected_keys.append(col)

            combo_key = tuple(selected_keys)

            if combo_key not in used_combos:
                used_combos.add(combo_key)
                combo_log.append(combo_key)
                break  # 找到一个新的组合

        # 输出目录和文件名
        outdir = os.path.join(output_all, f"{stage}_{i}")
        os.makedirs(outdir, exist_ok=True)

        outfile_name = "_".join([col.replace(".bw", "") for col in selected_keys]) + f"_{stage}_{i}.tsv"
        outfile_path = os.path.join(outdir, outfile_name)

        # 合并数据（按行拼接）
        combined_df = pd.DataFrame()
        for marker in markers:
            df = marker_to_df[marker][["region", selected[marker]]].copy()
            df = df.rename(columns={selected[marker]: marker})
            combined_df = pd.concat([combined_df, df], axis=0)

        # 写出文件
        combined_df.to_csv(outfile_path, sep="\t", index=False)
        print(f"✅ Written: {outfile_path}")

    # 写出组合日志
    log_file = os.path.join(output_all, f"{stage}_random_combination_log.tsv")
    with open(log_file, "w") as f:
        header = "\t".join(markers) + "\tcombo_id"
        f.write(header + "\n")
        for i, combo in enumerate(combo_log, 1):
            line = "\t".join(combo)
            f.write(f"{line}\t{stage}_{i}\n")

    print(f"📄 Combination log saved to: {log_file}")
