import pandas as pd
import re
import os

# 用列表保持 marker 顺序
markers = ["H3K27ac", "H3K9me3", "H3K4me3", "H3K4me1", "H3K27me3", "H3K36me3"]

for marker in markers:
    input_file = f"{marker}_signal_matrix_with_regions.tsv"
    print(f"Processing {input_file} ...")
    df = pd.read_csv(input_file, sep="\t")

    # 提取列名
    columns = df.columns.tolist()
    region_col = ["region"]

    # 构建 stage -> 列名映射
    stage_to_cols = {}

    for col in columns[1:]:  # 跳过 region
        match = re.match(fr"{marker}_([^_]+)_\d+\.bw", col)
        if match:
            stage = match.group(1)
            if stage not in stage_to_cols:
                stage_to_cols[stage] = []
            stage_to_cols[stage].append(col)

    # 写入对应文件夹和文件
    for stage, stage_cols in stage_to_cols.items():
        out_df = df[region_col + stage_cols]
        output_dir = stage
        os.makedirs(output_dir, exist_ok=True)
        out_file = os.path.join(output_dir, f"{marker}_{stage}_signal_matrix.tsv")
        out_df.to_csv(out_file, sep="\t", index=False)
        print(f"  → Written: {out_file} ({len(stage_cols)} samples)")

