import pandas as pd
input_dir = "/mnt/helab3/yyhan/Projects/embryo_classification/Tables/GEO_fastq_list/merged_fastq_info.csv"
# 读取原始 CSV 文件
df = pd.read_csv(input_dir)

# 对 sample_name 分组编号
df["sample_name_indexed"] = df.groupby("sample_name").cumcount() + 1
df["sample_name_numbered"] = df["sample_name"] + "_" + df["sample_name_indexed"].astype(str)

# 保存结果
df.to_csv("/mnt/helab3/yyhan/Projects/embryo_classification/Tables/GEO_fastq_list/geo_samples_numbered.csv", index=False)


