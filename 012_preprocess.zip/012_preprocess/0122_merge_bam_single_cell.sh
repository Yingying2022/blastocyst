#!/bin/bash

# sample list
sample=$1
output_path="merged_bam_fq20"
mkdir -p $output_path


echo "Processing ${sample}"
# 遍历每个细胞类型


# 查找符合当前细胞类型的 BAM 文件
bam_list=()
for bam_file in "$sample"/rmdup_bam/*.bam; do
    if [[ -f "$bam_file" ]]; then
        bam_list+=("$bam_file")
    fi
done
echo "${bam_list[@]}"
# 如果有符合当前细胞类型的文件，进行合并
if [[ ${#bam_list[@]} -gt 0 ]]; then
    # 生成合并后的 BAM 文件名
    merged_bam="${sample}_merged.bam"

    # 合并 BAM 文件并输出到该目录中
    echo "Merging BAM files for $sample..."
    samtools merge -o "${output_path}/${merged_bam}" "${bam_list[@]}"
    echo "Merged BAM for $sample stored in $sample/$merged_bam"
else
    echo "No BAM files found for $sample."
fi

echo "Done!"
