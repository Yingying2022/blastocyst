#!/bin/bash
echo "Starting MACS2 peak calling..."
cutoff=0.6
# 设置输出目录
output_dir="../merged_bam_20fq_callpeak_${cutoff}"
mkdir -p "$output_dir"
bam_dir="." # 当前目录下的 BAM 文件所在目录

# 遍历当前目录下的所有 BAM 文件
# 并使用 macs2 进行 peak calling
for i in "$bam_dir"/*.bam
do
    base=$(basename "$i" ".bam")
    macs2 callpeak \
    -t "$i" \
    -f BAMPE \
    -g hs \
    -q $cutoff \
    --nomodel \
    --nolambda \
    --broad \
    --broad-cutoff $cutoff \
    --outdir "$output_dir" \
    -n "${base}_${cutoff}"
done

echo "******* MACS2 peak calling completed. Results are in ${output_dir}."
