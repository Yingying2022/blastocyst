#!/bin/bash

# 创建 CSV 输出文件并写入表头
output_csv="sample_peak_counts_merged_0.8_peaks_sorted_mainpeak_flanked5kb_dist_5000_merged.csv"
echo "sample,Peak_file,Peak_Count" > "$output_csv"

# 遍历每个文件夹
for peak_file in *bed; do
    sample=$(basename "$peak_file" _merged_0.8_peaks_sorted_mainpeak_flanked5kb_dist_5000_merged.bed)
    echo "Processing sample: $sample"
    # 统计每个 .bed 文件的 peak 数量（行数）
    peak_count=$(wc -l < "$peak_file")
    # 将结果追加到 CSV 文件
    echo "$sample,$peak_file,$peak_count" >> "$output_csv"

done

echo "CSV output saved to $output_csv"


## 创建 CSV 输出文件并写入表头
#output_csv="sample_filtered_peak_counts.csv"
#echo "sample,Peak_file,Peak_Count" > "$output_csv"
#
## 遍历每个文件夹
#for peak_file in *filtered_qValue_gt2.broadPeak; do
#    sample=$(basename "$peak_file" _merged_0.05.filtered_qValue_gt2.broadPeak)
#    echo "Processing sample: $sample"
#    # 统计每个 .bed 文件的 peak 数量（行数）
#    peak_count=$(wc -l < "$peak_file")
#    # 将结果追加到 CSV 文件
#    echo "$sample,$peak_file,$peak_count" >> "$output_csv"
#
#done
#
#echo "CSV output saved to $output_csv"


#
## 创建 CSV 输出文件并写入表头
#output_csv="sample_filtered_by_pValue_gt5_peak_counts.csv"
#echo "sample,Peak_file,Peak_Count" > "$output_csv"
#
## 遍历每个文件夹
#for peak_file in *filtered_by_pvalue_gt5.broadPeak; do
#    sample=$(basename "$peak_file" _merged_0.05.filtered_by_pvalue_gt5.broadPeak)
#    echo "Processing sample: $sample"
#    # 统计每个 .bed 文件的 peak 数量（行数）
#    peak_count=$(wc -l < "$peak_file")
#    # 将结果追加到 CSV 文件
#    echo "$sample,$peak_file,$peak_count" >> "$output_csv"
#
#done
#
#echo "CSV output saved to $output_csv"

