#!/bin/bash
output_dir="bigWig_merged_bam"
mkdir -p $output_dir

THREADS=${THREADS:-10}  # 默认 8 线程

#echo "Index BAM"
#for bam in *_merged.bam; do
#    samtools index "$bam"
#done

echo "[step 1] Normalize BAM to bigWig"
for bam in *_merged.bam; do
    base=$(basename "$bam" ".bam")
    total_reads=$(samtools view -c "$bam")
    scale_factor=$(awk "BEGIN {printf \"%.5f\", 10000000 / $total_reads}")
    bamCoverage \
        --scaleFactor "$scale_factor" \
        -b "$bam" \
        -e 300 --smoothLength 500 -p "$THREADS" \
        -o "${output_dir}/${base}.ext300.smo500.bw"
done

mkdir -p insert_info
echo "[step 2] Insert Size Metrics (Picard)"
for bam in *_merged.bam; do
    base=$(basename "$bam" "_merged.bam")
    picard CollectInsertSizeMetrics \
        I="$bam" \
        O=insert_info/"$base"_insertMetrics.txt \
        H=insert_info/"$base"_insertHistogram.pdf \
        M=0.5
done