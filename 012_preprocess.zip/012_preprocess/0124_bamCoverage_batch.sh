#!/bin/bash
# 读取 metadata.csv，跳过第一行
metadata_file="/mnt/helab3/yyhan/Projects/embryo_classification/Tables/GEO_fastq_list/sample_list.txt"
process="/mnt/helab3/yyhan/Projects/embryo_classification/script/01_fastq_line/012_preprocess/0124_bamCoverage.sh"

# 使用 tr 删除 \r 并直接读取每行（假设每行只有一个字段，即样本名）
tr -d '\r' < "$metadata_file" | while read -r sample; do
    echo "Processing: [$sample]"  # 调试：看看变量是否干净
    # 确保输出目录存在
    mkdir -p "../logs"
    nohup bash $process "$sample" > "../logs/0124_bamCoverage_$sample.log" 2>&1 &
done

# 等待所有后台进程完成
wait

echo "Done!"
