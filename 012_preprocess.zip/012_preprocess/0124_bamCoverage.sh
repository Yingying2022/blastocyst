#!/bin/bash

sample=$1
cd "$sample" || exit

output_dir="bigWig"
mkdir -p $output_dir

THREADS=${THREADS:-10}  # 默认 8 线程

echo "Index BAM"
for bam in rmdup_bam/*_rmdup.bam; do
    samtools index "$bam"
done

echo "Normalize BAM to bigWig"
for bam in rmdup_bam/*_rmdup.bam; do
    base=$(basename "$bam" "_rmdup.bam")
    total_reads=$(samtools view -c "$bam")
    scale_factor=$(awk "BEGIN {printf \"%.5f\", 10000000 / $total_reads}")
    bamCoverage \
        --scaleFactor "$scale_factor" \
        -b "$bam" \
        -e 300 --smoothLength 500 -p "$THREADS" \
        -o "${output_dir}/${base}.ext300.smo500.bw"
done


cd ..
