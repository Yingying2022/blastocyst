#!/bin/bash

# sample list
sample_path="/mnt/helab3/yyhan/Projects/embryo_classification/Tables/GEO_fastq_list/sample_list.txt"
output_path="merged_bam_fq20"
mkdir -p $output_path

sample_list=()
while IFS= read -r line; do
    sample_list+=("$line")
done < "$sample_path"
echo "${sample_list[@]}"
# 遍历每个细胞类型

for sample in "${sample_list[@]}"; do
    # 查找符合当前细胞类型的 BAM 文件
    bam_list=()
    for bam_file in "$sample"/rmdup_bam/*.bam; do
        if [[ -f "$bam_file" ]]; then
            bam_list+=("$bam_file")
        fi
    done

    # 如果有符合当前细胞类型的文件，进行合并
    if [[ ${#bam_list[@]} -gt 0 ]]; then
        # 生成合并后的 BAM 文件名
        merged_bam="${sample}_merged.bam"

        # 合并 BAM 文件并输出到该目录中
        echo "Merging BAM files for $sample..."
        samtools merge -o "${output_path}/${merged_bam}" "${bam_list[@]}"
        echo "Merged BAM for $sample stored in $sample/$merged_bam"
    else
        echo "No BAM files found for $sample."
    fi
done

echo "Done!"
