fq_dir=$1
cd "$fq_dir" || exit

genome_index="/mnt/helab1/00_public/02_genome/11_mm10/bwt2_index/mm10"
threads=40

# 1. Bowtie2 比对
aligned_sam="../aligned_sam"
mkdir -p "$aligned_sam"

echo "[Step 1] Alignment"
for i in *_1.fastq; do
    base=$(basename "$i" _1.fastq)
    bowtie2 -x $genome_index \
        -1 "$base"_1.fastq \
        -2 "$base"_2.fastq \
        --dovetail \
        --very-sensitive-local \
        --no-unal \
        --no-mixed \
        --no-discordant \
        -X 2000 \
        -S "$aligned_sam"/"$base".mm10.sam \
        2> "$aligned_sam"/"$base".bowtie2.align.log -p $threads || {
            echo "!!! bowtie2 failed for $base"
            continue
        }
    echo ">>> Finished bowtie2 for $base"
done


# 2. 使用 samtools 处理 SAM 文件
sorted_bam="../sorted_bam"
mkdir -p "$sorted_bam"

echo "[Step 2] SAM to sorted BAM (uniq)"
for i in "$aligned_sam"/*.sam; do
    base=$(basename "$i" ".sam")
    samtools view -@ "$threads" -hbS -q 30 "$i" | \
    samtools sort -@ "$threads" -T "$aligned_sam"/"$base".mm10 - > "$sorted_bam"/"$base"_unique.bam
done

rm -f "$aligned_sam"/*.sam

logs="../logs"
mkdir -p "$logs"
# 3. 提取 bowtie2 align log 中的 overall 信息
echo "[step 3] Extract bowtie2 align info"
for i in "$aligned_sam"/*.bowtie2.align.log; do
    base=$(basename "$i" ".bowtie2.align.log")
    awk '/overall/{print $1}' "$i" >> "$logs"/Mapping.txt
    echo "$base" >> "$logs"/MappingID.txt
done

# 4. 使用 Picard 标记重复
rmdup_bam="../rmdup_bam"
mkdir -p "$rmdup_bam"
echo "[Step 4] Remove Duplicates (Picard)"
for i in "$sorted_bam"/*_unique.bam; do
    base=$(basename "$i" "_unique.bam")
    picard MarkDuplicates \
        REMOVE_DUPLICATES=true \
        I="$i" \
        o="$rmdup_bam"/"$base"_rmdup.bam \
        M="$rmdup_bam"/"$base"_picard.txt
done

# 5. 使用 bamtools 获取统计信息
echo "[Step 5] Extract other info"
for i in "$sorted_bam"/*_unique.bam; do
    base=$(basename "$i" "_unique.bam")
    bamtools stats -in "$i" > "$logs"/"$base".sam.uni.totalreads.log
done

# 6. 从 sam.uni.totalreads.log 提取 Total 信息
for i in "$logs"/*.sam.uni.totalreads.log; do
    base=$(basename "$i" ".sam.uni.totalreads.log")
    awk '/Total/{print $3}' "$i" >> "$logs"/Unimap.txt
    echo "$base" >> "$logs"/UnimapID.txt
done

# 7. 获取去重后的 bamtools 统计信息
for i in "$rmdup_bam"/*_rmdup.bam; do
    base=$(basename "$i" "_rmdup.bam")
    bamtools stats -in "$i" > "$logs"/"$base".sam.rmdup.totalreads.log
done

# 8. 从 sam.rmdup.totalreads.log 提取 Total 信息
for i in "$logs"/*.sam.rmdup.totalreads.log; do
    base=$(basename "$i" ".sam.rmdup.totalreads.log")
    awk '/Total/{print $3}' "$i" >> "$logs"/rmdup.txt
    echo "$base" >> "$logs"/rmdupID.txt
done

# nohup bash ../preprocess_tacit.sh > ../preprocess_tacit.log 2>&1 &

cd ..