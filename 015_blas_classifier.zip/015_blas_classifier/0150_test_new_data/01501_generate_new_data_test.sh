#!/bin/bash

sample=$1
cd "$sample" || exit

output_dir="bigWig"
mkdir -p $output_dir

THREADS=${THREADS:-10}  # 默认 8 线程

# 使用 Picard 标记重复
mkdir -p rmdup_bam
echo "[Step 1] Remove Duplicates (Picard)"
for i in sorted_bam/*_unique.bam; do
    base=$(basename "$i" "_unique.bam")
    picard MarkDuplicates \
        REMOVE_DUPLICATES=true \
        I="$i" \
        o=rmdup_bam/"$base"_rmdup.bam \
        M=rmdup_bam/"$base"_picard.txt
done



echo "[Step 2] Index BAM"
for bam in rmdup_bam/*_rmdup.bam; do
    samtools index "$bam"
done

echo "[Step 3] Normalize BAM to bigWig"
for bam in rmdup_bam/*_rmdup.bam; do
    base=$(basename "$bam" "_rmdup.bam")
    total_reads=$(samtools view -c "$bam")
    scale_factor=$(awk "BEGIN {printf \"%.5f\", 10000000 / $total_reads}")
    bamCoverage \
        --scaleFactor "$scale_factor" \
        -b "$bam" \
        -e 300 --smoothLength 500 -p "$THREADS" \
        -o "${output_dir}/${base}.ext300.smo500.bw"
done

echo "[Step 4] Extract other info"
# 使用 bamtools 获取统计信息
mkdir -p logs
for i in sorted_bam/*_unique.bam; do
    base=$(basename "$i" "_unique.bam")
    bamtools stats -in "$i" > logs/"$base".sam.uni.totalreads.log
done

# 获取去重后的 bamtools 统计信息
for i in rmdup_bam/*_rmdup.bam; do
    base=$(basename "$i" "_rmdup.bam")
    bamtools stats -in "$i" > logs/"$base".sam.rmdup.totalreads.log
done

cd ..
