import pandas as pd
import numpy as np
import joblib
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix, roc_curve, auc, classification_report, accuracy_score
from sklearn.preprocessing import label_binarize
from datetime import datetime

# 1. 加载模型和预处理器
model = joblib.load("best_model.pkl")
label_encoder = joblib.load("label_encoder.pkl")
scaler = joblib.load("scaler.pkl")
pca = joblib.load("pca.pkl")

# 2. 读取新数据（假设最后一列是真实标签）
new_df = pd.read_csv("new_data.tsv", sep='\t', header=None)

# 如果有标签
if new_df.shape[1] > 1:
    X_new = new_df.iloc[:, :-1].values
    y_true_labels = new_df.iloc[:, -1].values
    y_true_encoded = label_encoder.transform(y_true_labels)
else:
    X_new = new_df.values
    y_true_labels = None

# 3. 预处理
X_new_scaled = scaler.transform(X_new)
X_new_pca = pca.transform(X_new_scaled)

# 4. 预测
y_pred_encoded = model.predict(X_new_pca)
y_pred_labels = label_encoder.inverse_transform(y_pred_encoded)

# 5. 保存预测结果
output_df = pd.DataFrame({
    "Sample_ID": range(len(y_pred_labels)),
    "Predicted_Label": y_pred_labels
})
if y_true_labels is not None:
    output_df["True_Label"] = y_true_labels
output_df.to_csv("predictions.tsv", sep='\t', index=False)

print("✅ 预测完成，结果已保存到 predictions.tsv")

# 6. 如果有真实标签，就画评估图
if y_true_labels is not None:
    classes = label_encoder.classes_
    n_classes = len(classes)

    y_score = model.predict_proba(X_new_pca)

    fig, axes = plt.subplots(1, 3, figsize=(18, 5))

    # 1️⃣ 混淆矩阵
    cm = confusion_matrix(y_true_encoded, y_pred_encoded)
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                xticklabels=classes, yticklabels=classes, ax=axes[0])
    acc = accuracy_score(y_true_encoded, y_pred_encoded)
    axes[0].set_title(f"Confusion Matrix\nAccuracy: {acc:.2%}")
    axes[0].set_xlabel("Predicted")
    axes[0].set_ylabel("True")

    # 2️⃣ ROC 曲线
    y_true_bin = label_binarize(y_true_encoded, classes=np.arange(n_classes))
    fpr, tpr, roc_auc = {}, {}, {}
    for i in range(n_classes):
        fpr[i], tpr[i], _ = roc_curve(y_true_bin[:, i], y_score[:, i])
        roc_auc[i] = auc(fpr[i], tpr[i])
        axes[1].plot(fpr[i], tpr[i], lw=2, label=f"{classes[i]} (AUC = {roc_auc[i]:.2f})")
    fpr["micro"], tpr["micro"], _ = roc_curve(y_true_bin.ravel(), y_score.ravel())
    roc_auc["micro"] = auc(fpr["micro"], tpr["micro"])
    axes[1].plot(fpr["micro"], tpr["micro"], linestyle='--', color='black',
                label=f"micro-average (AUC = {roc_auc['micro']:.2f})")
    axes[1].plot([0, 1], [0, 1], 'k--', lw=1)
    axes[1].set_xlim([0.0, 1.0])
    axes[1].set_ylim([0.0, 1.05])
    axes[1].set_xlabel('False Positive Rate')
    axes[1].set_ylabel('True Positive Rate')
    axes[1].set_title("ROC Curve")
    axes[1].legend(loc="lower right")

    # 3️⃣ AUC 柱状图
    auc_values = [roc_auc[i] for i in range(n_classes)]
    axes[2].bar(classes, auc_values, color='skyblue')
    axes[2].set_ylim(0, 1.0)
    axes[2].set_ylabel("AUC")
    axes[2].set_title("AUC per Class")
    for i, v in enumerate(auc_values):
        axes[2].text(i, v + 0.02, f"{v:.2f}", ha='center', fontsize=10)

    plt.tight_layout()
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    plt.savefig(f"newdata_eval_{timestamp}.png", dpi=300, bbox_inches='tight')
    plt.close()

    print("📊 评估图已保存到 newdata_eval_{timestamp}.png")
