import os
import pandas as pd
import numpy as np
import joblib
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score, roc_curve, auc
from sklearn.preprocessing import label_binarize, LabelEncoder, StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.decomposition import PCA
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from xgboost import XGBClassifier
import seaborn as sns
import matplotlib.pyplot as plt

outdir = "figures_classifier_performance"
os.makedirs(outdir, exist_ok=True)

def plot_multiclass_eval(y_test, y_pred, y_score, label_encoder, model_name, save_path=None):
    classes = label_encoder.classes_
    n_classes = len(classes)
    fig, axes = plt.subplots(1, 3, figsize=(18, 5))

    # 1️⃣ 混淆矩阵
    cm = confusion_matrix(y_test, y_pred)
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                xticklabels=classes, yticklabels=classes, ax=axes[0])
    axes[0].set_title(f"{model_name} - Confusion Matrix")
    axes[0].set_xlabel("Predicted")
    axes[0].set_ylabel("True")

    # 2️⃣ ROC 曲线
    y_test_bin = label_binarize(y_test, classes=np.arange(n_classes))
    fpr, tpr, roc_auc = {}, {}, {}
    for i in range(n_classes):
        fpr[i], tpr[i], _ = roc_curve(y_test_bin[:, i], y_score[:, i])
        roc_auc[i] = auc(fpr[i], tpr[i])
        axes[1].plot(fpr[i], tpr[i], lw=2, label=f"{classes[i]} (AUC = {roc_auc[i]:.2f})")
    fpr["micro"], tpr["micro"], _ = roc_curve(y_test_bin.ravel(), y_score.ravel())
    roc_auc["micro"] = auc(fpr["micro"], tpr["micro"])
    axes[1].plot(fpr["micro"], tpr["micro"], linestyle='--', color='black',
                label=f"micro-average (AUC = {roc_auc['micro']:.2f})")
    axes[1].plot([0, 1], [0, 1], 'k--', lw=1)
    axes[1].set_xlim([0.0, 1.0])
    axes[1].set_ylim([0.0, 1.05])
    axes[1].set_xlabel('False Positive Rate')
    axes[1].set_ylabel('True Positive Rate')
    axes[1].set_title(f"{model_name} - ROC Curve")
    axes[1].legend(loc="lower right")

    # 3️⃣ AUC 柱状图
    auc_values = [roc_auc[i] for i in range(n_classes)]
    axes[2].bar(classes, auc_values, color='skyblue')
    axes[2].set_ylim(0, 1.0)
    axes[2].set_ylabel("AUC")
    axes[2].set_title(f"{model_name} - AUC per Class")
    for i, v in enumerate(auc_values):
        axes[2].text(i, v + 0.02, f"{v:.2f}", ha='center', fontsize=10)

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.close(fig)
    else:
        plt.show()

# 1. 加载数据
df = pd.read_csv("transposed_with_stage.tsv", sep='\t')
X = df.iloc[:, :-2].values
y = df.iloc[:, -1].values

# 2. 标签编码
label_encoder = LabelEncoder()
y_encoded = label_encoder.fit_transform(y)

# 3. 标准化
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# 4. PCA 降维
pca = PCA(n_components=200)
X_pca = pca.fit_transform(X_scaled)

# 5. 划分数据集
X_train, X_temp, y_train, y_temp = train_test_split(
    X_pca, y_encoded, test_size=0.3, random_state=42, stratify=y_encoded
)
X_val, X_test, y_val, y_test = train_test_split(
    X_temp, y_temp, test_size=0.5, random_state=42, stratify=y_temp
)

# 6. 模型列表
models = {
    "RandomForest": RandomForestClassifier(n_estimators=100, n_jobs=-1, random_state=42),
    "XGBoost": XGBClassifier(n_estimators=100, eval_metric='mlogloss', random_state=42),
    "LogisticRegression": LogisticRegression(max_iter=1000, solver='lbfgs')
}

# 7. 训练 + 保存最佳模型
best_acc = 0
best_model_name = None

for name, model in models.items():
    print(f"\n===== {name} =====")
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    print(f"Test Accuracy: {acc:.4f}")
    print(classification_report(y_test, y_pred, target_names=label_encoder.classes_))

    y_score = model.predict_proba(X_test) if hasattr(model, "predict_proba") else model.decision_function(X_test)

    plot_multiclass_eval(
        y_test, y_pred, y_score,
        label_encoder, name,
        save_path=os.path.join(outdir, f"{name}_eval.png")
    )

    if acc > best_acc:
        best_acc = acc
        best_model_name = name
        joblib.dump(model, "best_model.pkl")
        joblib.dump(label_encoder, "label_encoder.pkl")
        joblib.dump(scaler, "scaler.pkl")
        joblib.dump(pca, "pca.pkl")

print(f"\n✅ 最佳模型: {best_model_name} (Acc={best_acc:.4f}) 已保存")
