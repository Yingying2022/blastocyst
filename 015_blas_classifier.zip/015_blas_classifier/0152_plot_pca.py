from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.preprocessing import LabelEncoder, StandardScaler
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

# 1. 加载数据
df = pd.read_csv("transposed_with_stage.tsv", sep='\t')
X = df.iloc[0:600, :-2].values
y = df.iloc[0:600, -1].values

# 2. 标签编码
label_encoder = LabelEncoder()
y_encoded = label_encoder.fit_transform(y)

# 3. 标准化
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# 4. PCA 降维
# ===== PCA + 聚类分析 =====
def pca_cluster_analysis(X, y, label_encoder, n_clusters=None, save_path=None):
    """
    X: 特征矩阵
    y: 整数编码标签
    label_encoder: 已训练好的 LabelEncoder
    n_clusters: 聚类簇数，默认等于类别数
    """
    if n_clusters is None:
        n_clusters = len(label_encoder.classes_)

    # PCA 降到 2 维方便可视化
    pca = PCA(n_components=2)
    X_pca = pca.fit_transform(X)

    # 聚类
    kmeans = KMeans(n_clusters=n_clusters, random_state=42)
    cluster_labels = kmeans.fit_predict(X_pca)

    # 计算轮廓系数
    silhouette_avg = silhouette_score(X_pca, cluster_labels)
    print(f"PCA+KMeans silhouette score: {silhouette_avg:.4f}")

    # 绘制真实标签分布
    plt.figure(figsize=(12, 5))
    plt.subplot(1, 2, 1)
    sns.scatterplot(x=X_pca[:, 0], y=X_pca[:, 1],
                    hue=label_encoder.inverse_transform(y),
                    palette="tab10", s=30, alpha=0.7)
    plt.title("PCA Projection (True Labels)")
    plt.xlabel("PC1")
    plt.ylabel("PC2")
    plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left', fontsize=8)

    # 绘制聚类结果
    plt.subplot(1, 2, 2)
    sns.scatterplot(x=X_pca[:, 0], y=X_pca[:, 1],
                    hue=cluster_labels,
                    palette="tab10", s=30, alpha=0.7)
    plt.title(f"PCA Projection (KMeans Clusters, k={n_clusters})")
    plt.xlabel("PC1")
    plt.ylabel("PC2")
    plt.legend(title="Cluster", bbox_to_anchor=(1.05, 1), loc='upper left', fontsize=8)

    plt.tight_layout()

    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.close()
    else:
        plt.show()

# ===== 调用方法 =====
# 这里用 PCA 前的数据 X_scaled 或者 X_pca（都可以）
pca_cluster_analysis(X_scaled, y_encoded, label_encoder,
                    save_path="pca_kmeans_clusters.png")
