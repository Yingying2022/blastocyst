#!/bin/bash

# 定义目标和源路径
dest_root="/mnt/helab3/yyhan/Projects/embryo_classification/dataset/fastq"
source_dir="/mnt/helab1/00_public/03_public_data/06_Mouse_embryo_TACIT/GSE235109_all/fastq"

# 读取 metadata.csv，跳过第一行
tail -n +2 ../Tables/GEO_fastq_list/merged_fastq_info.csv | while IFS=$',' read -r geo srr sample
do
  # 创建对应的 sample_name 文件夹（如果不存在）
  dest_folder="$dest_root/$sample"
  mkdir -p "$dest_folder"

  # 查找并创建软链接
  for suffix in 1 2; do
    fq="${srr}_${suffix}.fastq"
    source_fq="$source_dir/$fq"  # 构建源文件的完整路径

    # 检查源文件是否存在
    if [[ -f "$source_fq" ]]; then
      # 创建软链接到目标文件夹
      ln -sf "$source_fq" "$dest_folder/$fq"
      echo "Linked: $source_fq -> $dest_folder/$fq"
    else
      echo "WARNING: Source file not found: $source_fq"
    fi
  done
done

# nohup bash /mnt/helab3/yyhan/Projects/embryo_classification/script/softlink_fastq.sh > /mnt/helab3/yyhan/Projects/embryo_classification/script/softlink_fastq.log 2>&1 &