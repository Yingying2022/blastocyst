#!/bin/bash

srr_list="common_in_sorted_present_missing.txt"
source_dir="./fastq3"         # 原始 fastq 文件所在目录
target_dir="./fastq_final"    # 目标目录

mkdir -p "$target_dir"

while read -r srr; do
    # 跳过空行
    [ -z "$srr" ] && continue

    for suffix in 1 2; do
        src_file="$source_dir/${srr}_${suffix}.fastq"
        tgt_file="$target_dir/${srr}_${suffix}.fastq"

        if [ ! -f "$src_file" ]; then
            echo "[WARN] 源文件不存在: $src_file"
            continue
        fi

        if [ -f "$tgt_file" ]; then
            # 如果目标文件存在，比较大小
            src_size=$(stat -c %s "$src_file")
            tgt_size=$(stat -c %s "$tgt_file")

            if [ "$src_size" -eq "$tgt_size" ]; then
                echo "[SKIP] $tgt_file 已存在且大小相同，跳过"
                continue
            else
                echo "[INFO] $tgt_file 已存在但大小不同，将覆盖"
            fi
        fi

        # 移动文件（也可以改为 cp 复制）
        mv "$src_file" "$tgt_file"
        echo "[DONE] 移动 $src_file → $tgt_file"
    done
done < "$srr_list"
