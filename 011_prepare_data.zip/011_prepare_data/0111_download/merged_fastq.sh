#!/bin/bash

# 定义目标目录
merged_dir="/mnt/helab3/yyhan/Projects/embryo_classification/dataset/merged_fastq"

# 确保目标文件夹存在
mkdir -p "$merged_dir"

# 读取 list.txt 中的文件夹并并行执行任务
cat list.txt | while read folder; do
  if [ -d "$folder" ]; then
    # 提取文件夹名作为样本名
    sample_name=$(basename "$folder")

    # 定义合并后的目标文件
    merged_file_1="$merged_dir/${sample_name}_1.fastq"
    merged_file_2="$merged_dir/${sample_name}_2.fastq"

    # 定义合并函数
    merge_fastq_files() {
      # 查找并合并 *1.fastq 文件
      echo "Merging *1.fastq files in $folder into $merged_file_1"
      ls "$folder"/*1.fastq  # 输出匹配的文件
      cat "$folder"/*1.fastq > "$merged_file_1"

      # 查找并合并 *2.fastq 文件
      echo "Merging *2.fastq files in $folder into $merged_file_2"
      ls "$folder"/*2.fastq  # 输出匹配的文件
      cat "$folder"/*2.fastq > "$merged_file_2"

      echo "Merged: $merged_file_1 and $merged_file_2"
    }

    # 在后台执行每个文件夹的合并任务，并确保该任务完成后才执行后续操作
    merge_fastq_files &

  fi
done

wait

echo "All merging tasks completed."
