#!/bin/bash

# 定义目标目录
merged_dir="/mnt/helab3/yyhan/Projects/embryo_classification/dataset/merged_fastq20"
max_file=20
# 确保目标文件夹存在
mkdir -p "$merged_dir"

# 读取 list.txt 中的文件夹并并行执行任务
folder="H3K27me3_zygote"
if [ -d "$folder" ]; then
  # 提取文件夹名作为样本名
  sample_name=$(basename "$folder")

  # 定义合并后的目标文件
  merged_file_1="$merged_dir/${sample_name}_1.fastq"
  merged_file_2="$merged_dir/${sample_name}_2.fastq"

  # 使用 find 查找 *1.fastq 文件并限制最多 20 个文件
  mapfile -t fastq1_files < <(find "$folder" -maxdepth 1 -type l -name "*1.fastq" | head -n $max_file)

  # 使用 find 查找 *2.fastq 文件并限制最多 20 个文件
  mapfile -t fastq2_files < <(find "$folder" -maxdepth 1 -type l -name "*2.fastq" | head -n $max_file)

  # 输出文件数量
  echo "Folder: $folder"
  echo "Number of *1.fastq files to merge: ${#fastq1_files[@]}"
  echo "Number of *2.fastq files to merge: ${#fastq2_files[@]}"

  # 合并 *1.fastq 文件
  echo "Merging *1.fastq files in $folder into $merged_file_1"
  cat "${fastq1_files[@]}" > "$merged_file_1"

  # 合并 *2.fastq 文件
  echo "Merging *2.fastq files in $folder into $merged_file_2"
  cat "${fastq2_files[@]}" > "$merged_file_2"

  echo "Merged: $merged_file_1 and $merged_file_2"
fi


wait

echo "All merging tasks completed."

#nohup bash /mnt/helab3/yyhan/Projects/embryo_classification/script/merged_fastq20.sh > /mnt/helab3/yyhan/Projects/embryo_classification/script/merged_fastq20.log 2>&1 &