# 统计 *1.fastq 文件的数量
for folder in ./*; do
    fastq1_count=$(find "$folder"/*1.fastq 2>/dev/null | wc -l)

    # 输出文件数量
    echo "Folder: $folder"
    echo "Number of *1.fastq files: $fastq1_count"

done