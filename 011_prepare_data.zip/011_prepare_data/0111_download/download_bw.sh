#pip install geofetch
geofetch -i GSE235109 --processed --geo-folder GSE235109_all_bw