import time

def read_bytes(interface):
    with open('/proc/net/dev', 'r') as f:
        for line in f:
            if interface in line:
                parts = line.strip().split()
                rx = int(parts[1])
                tx = int(parts[9])
                return rx, tx
    return 0, 0

def format_speed(bytes_per_sec):
    return f"{bytes_per_sec / (1024 * 1024):.2f} MB/s"

interface = 'enp0s31f6'  # 你活跃的网卡接口名
print(f"Monitoring interface: {interface}")
rx_prev, tx_prev = read_bytes(interface)

while True:
    time.sleep(1)
    rx_curr, tx_curr = read_bytes(interface)
    rx_rate = rx_curr - rx_prev
    tx_rate = tx_curr - tx_prev
    rx_prev, tx_prev = rx_curr, tx_curr
    print(f"[{time.strftime('%H:%M:%S')}]  RX: {format_speed(rx_rate)}  |  TX: {format_speed(tx_rate)}")
