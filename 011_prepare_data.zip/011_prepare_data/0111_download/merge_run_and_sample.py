#%%
import pandas as pd
#%%
# 读取两个表
runs = pd.read_csv('embryo_classification/Tables/GEO_fastq_list/data_GSM_SSR.csv')         # 表1：包含 GEO_accession 和 Run
samples = pd.read_csv('embryo_classification/Tables/GEO_fastq_list/data_GSM_marker_cellType.csv')   # 表2：包含 GEO_accession 和 sample_name

# 按 GEO_accession 合并
merged = pd.merge(runs, samples, on='GEO_accession', how='left')

# 保存结果
merged.to_csv('embryo_classification/Tables/GEO_fastq_list/merged_result.csv', index=False)



# 查看结果前几行
print(merged.head())
