#!/bin/bash

# ====== 参数设置 ======
#srr_list="./SRR_list1_GSE235109.txt"   # 每行一个 SRR 编号
srr_list="./only_in_missing_srr_fastq2.txt"  # 每行一个 SRR 编号
output_dir="./fastq"

done_file="./download_done_1supp_GSE235109_$(date +%Y%m%d_%H%M%S).txt"
log_file="./download_failed_1supp_GSE235109_$(date +%Y%m%d_%H%M%S).txt"
threads=20  # 并发线程数
max_retries=3

# ====== 初始化 ======
mkdir -p "$output_dir"
touch "$done_file"
touch "$log_file"

# ====== 定义单个任务的函数 ======
download_one_srr() {
    srr="$1"

    # 跳过空行
    if [ -z "$srr" ]; then
        exit 0
    fi

    # 已完成下载？
    if grep -q "^$srr$" "$done_file"; then
        echo "[SKIP] $srr 已完成，跳过"
        exit 0
    fi

    # fastq 文件已存在？
    if [ -f "$output_dir/${srr}_1.fastq" ] && [ -f "$output_dir/${srr}_2.fastq" ]; then
        echo "[SKIP] $srr fastq 文件已存在，记录并跳过"
        echo "$srr" >> "$done_file"
        exit 0
    fi


    echo "========== 开始处理 $srr =========="

    attempt=1
    success=0

    while [ "$attempt" -le "$max_retries" ]; do
        
        # 下载 .sra（断点续传，前先删锁）
        lock_file=$(find "$srr/" -type f -name "$srr.sra.lock" 2>/dev/null | head -n 1)

        if [[ -f "$lock_file" ]]; then
            echo "[INFO] 检测到锁文件，删除: $lock_file"
            rm -f "$srr/$srr.sra.lock"
        fi

        # 下载 .sra（断点续传）
        echo "[INFO] $srr 第 $attempt 次尝试下载"
        timeout 1800 prefetch --resume yes "$srr"
        if [ $? -ne 0 ]; then
            echo "[WARN] prefetch 失败: $srr（第 $attempt 次）"
            ((attempt++))
            sleep 10
            continue
        fi

        # 转换 fastq
        timeout 3600 fasterq-dump "$srr" -e 8 -O "$output_dir" --split-files
        if [ $? -ne 0 ]; then
            echo "[WARN] fasterq-dump 失败: $srr（第 $attempt 次）"
            ((attempt++))
            sleep 10
            continue
        fi

        # 清理 .sra 文件（忽略错误）
        rm -r "$srr" 2>/dev/null || true

        # 成功
        echo "$srr" >> "$done_file"
        echo "[DONE] $srr 下载完成 ✅"
        success=1
        break
    done

    if [ "$success" -eq 0 ]; then
        echo "[ERROR] $srr 下载失败 ❌" | tee -a "$log_file"
        exit 1
    fi
}

# ====== 导出函数和变量（用于 parallel） ======
export -f download_one_srr
export output_dir done_file log_file max_retries

# ====== 并发执行 ======
parallel -j "$threads" download_one_srr :::: "$srr_list"

