# 文件名示例：list1.txt 和 list2.txt
#%%
def extract_srr(file):
    with open(file) as f:
        return set(line.strip().split('_')[0] for line in f if line.strip())
srr1 = extract_srr("embryo_classification/Tables/GEO_fastq_list/GSE235109_1_fastq_list.txt")
srr2 = extract_srr("embryo_classification/Tables/GEO_fastq_list/GSE235109_2_fastq_list.txt")

only_in_1 = srr1 - srr2
only_in_2 = srr2 - srr1
both = srr1 & srr2

# 保存结果
with open("embryo_classification/Tables/only_in_list1.txt", "w") as f:
    for srr in sorted(only_in_1):
        f.write(srr + "\n")

with open("embryo_classification/Tables/only_in_list2.txt", "w") as f:
    for srr in sorted(only_in_2):
        f.write(srr + "\n")

with open("embryo_classification/Tables/shared_in_both.txt", "w") as f:
    for srr in sorted(both):
        f.write(srr + "\n")

print(f"[INFO] 保存完成：{len(only_in_1)} 只在 list1 中, {len(only_in_2)} 只在 list2 中, {len(both)} 共有")
